# Test Plan (Expanded): Replit 个人仪表盘 v1

## 1) Scope & Quality Gates
- 必过门禁：
  1. Auth/Session 正常 + 越权访问阻断
  2. Memo CRUD + 图片上传稳定
  3. 站内提醒在到点后显著可见
  4. 天气/城市/90天假期展示正确
  5. 中文 UI 与响应式核心流程可用

## 2) Unit Tests

### Auth & Session
- 密码哈希与校验函数
- 会话创建/续期/失效逻辑
- 登录限流器边界
- idle TTL / absolute TTL / 轮换策略
- session fixation / replay 防护辅助逻辑

### Authorization/Isolation
- 仓储层 `user_id` 过滤器必经路径
- 非本人 `memo_id` 查询/更新/删除返回拒绝

### Memo & Attachment
- memo 字段校验（标题、正文、时间）
- 上传 MIME/扩展名/size 校验
- 附件路径命名空间（按 user_id）
- 单图 5MB / 单 memo 1 图 / 用户软配额校验
- 替换/删除附件后的回收任务入队逻辑

### Reminder
- 到期判定函数（UTC/用户时区/边界）
- “已提醒/未提醒”状态机
- fake clock 下的 60 秒轮询容忍窗口
- 重连/重新聚焦后的补发规则

### Holiday Window
- 90 天窗口计算函数（含月末/闰年边界）
- provider 归一化、缓存 TTL、stale fallback 文案映射

## 2.1 Testability Mechanisms
- 注入式时钟接口：提醒与 90 天窗口测试必须可冻结/跳时
- Weather / Holiday provider 使用 contract mock + fixture，不直接依赖线上接口
- 对象存储使用测试替身或隔离 bucket，验证上传/删除/回收路径
- Replit 运行矩阵：本地预览、Replit 预览、冷启动重启后回归
- 恢复演练测试：从最近备份恢复数据库与附件索引并运行 smoke tests

## 3) Integration Tests (API + DB)
- 注册→登录→访问受保护资源
- A/B 两账号并行：互相读取/修改对方 memo 均失败
- 登出当前 session 后当前 cookie 失效；密码变更后全部 session 失效
- memo CRUD 全流程（含附件）
- 上传非法文件被拒，合法图片只能通过受保护附件 API 访问（仅本人）
- 删除/替换 memo 附件后对象回收任务被触发，孤儿扫描可发现异常对象
- 设置提醒后，到期查询 API 返回正确条目，确认后不再重复返回
- 关闭页面后重新登录/重新聚焦，已到期未确认提醒被补发
- 城市保存/切换后天气接口参数正确
- 假期接口返回严格未来 90 天区间
- 假期/天气 provider 失败时返回降级状态且 memo 主流程不受阻断

## 4) E2E Tests (Browser)
- 新用户首登流程（中文文案可见）
- 登录后创建 memo + 上传图片 + 编辑 + 删除
- 设置近期提醒，前端出现显著提示并可确认关闭
- 同账号双标签页场景下，确认后的提醒列表状态最终一致
- 手动选城市、保存常用城市、刷新后仍保持
- 假期模块展示未来 90 天条目
- 移动端视口（如 390x844）与桌面视口均可完成核心流程
- 未登录直接访问仪表盘会被重定向到登录页

## 5) Security/Privacy Tests
- 会话 Cookie 安全属性检查（HttpOnly/Secure/SameSite）
- CSRF 基线（关键写接口）
- 登录暴力尝试限流测试
- session fixation / rotation / replay 专项
- IDOR（不安全直接对象引用）专项：memo/attachment/city API
- 上传攻击样本（伪造 MIME、双扩展名、超限文件）
- 配额超限、孤儿对象、私有 bucket 配置专项

## 6) Observability & Runtime Validation
- 结构化日志字段：request_id, user_id(可脱敏), route, status, latency
- 关键指标：
  - 登录成功率/失败率
  - 4xx/5xx 比例
  - 上传失败率
  - 提醒触发次数与确认率
  - provider 降级次数
  - 恢复演练成功率
- 告警建议：
  - 5xx 激增
  - 上传拒绝率异常飙升
  - 鉴权失败异常峰值
  - provider 连续失败 / bucket 权限异常

## 7) Release Verification Checklist
1. 全部单测、集成、E2E 绿灯。
2. 越权与上传安全专项通过。
3. Replit 生产环境变量正确，未泄露 secrets。
4. 公网部署回归通过（新账号、旧账号、移动端）。
5. 最近一次恢复演练在 7 天内且满足 RPO/RTO 门禁。
6. 已产出发布证据包（测试报告 + 风险清单 + 已知限制）。
