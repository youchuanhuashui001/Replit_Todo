# Team Launch Playbook: replit-dashboard-v1

## Launch
```bash
omx team 6:executor "replit dashboard v1 delivery with auth isolation upload reminder weather holiday"
```

## Lane Assignment (owner + deliverables)
1. `architect` (high)
   - Deliverables: API contract, data model, auth/session semantics, durability/storage ADR checklist
2. `executor` (high)
   - Deliverables: auth/session + memo CRUD + upload + isolation guards + protected attachment API
3. `executor` (medium)
   - Deliverables: dashboard UI + reminder UX + weather + city favorites + 90-day holidays + degraded-state UI
4. `test-engineer` (high)
   - Deliverables: integration/e2e suite (auth isolation/upload/reminder/holiday window/recovery drill)
5. `security-reviewer` (medium)
   - Deliverables: IDOR + upload abuse + session rotation/fixation + private bucket/access-path report
6. `verifier` (high)
   - Deliverables: release evidence pack + go/no-go decision

## Gate Sequence
1. Design gate (1+5 sign-off)
2. Build gate (2+3 complete + lane unit tests pass)
3. Quality gate (4 all critical tests green)
4. Security gate (5 no unresolved high severity)
5. Release gate (6 evidence complete)

## Required Evidence Paths
- `.omx/state/team/<team>/tasks/`
- `.omx/state/team/<team>/mailbox/leader-fixed.json`
- Test reports: `artifacts/tests/*`
- Security report: `artifacts/security/*`
- Verification summary: `artifacts/release/*`

## Commit Hygiene Requirement
- Any auto-checkpoint/system-generated worker commits must be squashed/reworded into Lore-format final commits before merge/finalization.
