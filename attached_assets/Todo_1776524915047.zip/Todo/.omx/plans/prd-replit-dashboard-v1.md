# PRD + RALPLAN-DR + ADR: Replit 个人仪表盘（v1）

## 0) 目标与范围（来自 deep-interview 规格）
- 目标：在 Replit 公网部署一个中文个人仪表盘，支持账号体系、私密备忘录（含图片）、站内提醒、天气、常用城市、未来 90 天假期。
- 强约束：
  - 中文 UI
  - 注册/登录（不接第三方登录）
  - 用户数据隔离（公开部署但私有内容不可互看）
  - 仅站内提醒（无邮件/短信/系统通知）
  - 手动选城市并可保存常用城市
  - 假期展示固定未来 90 天
  - 无协作功能

---

## 1) RALPLAN-DR（Deliberate）

### A. Principles（5）
1. **隐私优先**：所有读写接口默认按 `user_id` 过滤，任何跨用户数据访问视为 P0 缺陷。
2. **最小可行闭环**：先打通“注册登录→私密 memo CRUD→图片→提醒→天气/城市→假期”的端到端路径。
3. **公开部署可控风险**：默认安全配置（密码哈希、会话安全、上传校验、速率限制、审计日志）。
4. **移动优先响应式**：同一账号在手机/平板/桌面可用，优先保证核心流程可达与可读。
5. **可验证交付**：每阶段都绑定可执行验收与测试证据，防止“功能有了但不可证明”。

### B. Top 3 Decision Drivers
1. **数据隔离与认证可靠性**（公开部署下的核心风险）
2. **Replit 上的可运维性与部署简洁度**（greenfield，需要快速落地）
3. **媒体上传与提醒时序的可实现性**（图片 + 到点提醒是 v1 差异点）

### C. Viable Options（>=2）

#### Option 1 — 单体 Next.js 全栈（App Router + API Routes + 托管 Postgres + 私有对象存储）
- Pros（边界）
  - 一套代码同时覆盖 UI/API，开发与部署路径短。
  - 适配 Replit 快速发布，适合 greenfield MVP。
  - 可直接做 SSR/CSR 混合，响应式与登录态管理成熟。
  - 将持久化与附件从 Replit 运行时剥离，降低重启/发布丢数据风险。
- Cons（边界）
  - 服务端与前端耦合，后续拆分 API 服务成本较高。
  - 长轮询/提醒调度能力受单体运行时约束。
  - 仍需管理外部数据库/对象存储凭证与备份策略。

#### Option 2 — 前后端分离（React SPA + Node API）
- Pros（边界）
  - 关注点清晰，后续扩展多端更自然。
  - API 层可独立扩展与限流。
- Cons（边界）
  - 对当前 scope 偏重：仓库空白下初始脚手架与部署复杂度更高。
  - Replit 上多进程/多服务编排与调试成本上升。

#### Option 3 — BaaS 主导（托管 Auth/Storage/DB）+ 薄前端
- Pros（边界）
  - Auth/存储快速就绪，开发速度快。
  - 内置策略能力可帮助隔离。
- Cons（边界）
  - 平台耦合与成本不确定；对 Replit + 公网场景需额外评估网络与密钥治理。
  - 可移植性与可控性较弱。

### D. Chosen Option
**选择 Option 1（单体 Next.js 全栈 + 托管持久化）**。

**Why chosen（有界结论）**：在 greenfield + 明确 v1 范围下，Option 1 用最少系统边界满足“认证隔离、图片上传、提醒、天气、假期、公开部署”的整体验证目标，能最快产出可证明的安全与功能闭环。

---

## 2) ADR

### Decision
采用 **Next.js 单体全栈架构**（UI + API 同仓）实现 v1；认证使用本地账号密码；运行时保持无状态；结构化数据落在**托管 Postgres**，图片落在**私有 S3 兼容对象存储**；所有业务表以 `user_id` 作为强制隔离主键；附件统一经受保护下载 API 授权；提醒由前端轮询/聚焦刷新与后端到期查询协同。

### Drivers
- 公开部署下的隐私与隔离必须优先可证。
- Replit 环境需要低运维复杂度、快速上线。
- v1 需覆盖图片与时序提醒，不能只做静态 CRUD。

### Alternatives considered
1. 前后端分离双服务架构（未选：启动/部署成本高于当前收益）。
2. 重度 BaaS 架构（未选：平台耦合与可控性风险较高）。

### Why chosen
- 单体架构可最短路径实现端到端能力并保留后续拆分空间。
- 更易在同一测试管线中完成认证、隔离、上传、提醒的联调与验收。

### Consequences
- 正向：开发速度快、系统边界少、交付路径清晰；Replit 运行时不承担持久化职责。
- 负向：后续高并发扩展需重构；提醒能力在浏览器关闭时不可达（符合当前“仅站内提醒”约束）；需要维护外部存储/备份与密钥治理。

### Follow-ups
1. v1.1 评估后台任务/推送扩展（若未来需要离线提醒）。
2. v1.1 评估对象存储升级策略（当图片量增长）。
3. v1.1 评估 API/前端拆分条件（性能与团队规模触发）。

### 2.1 Durability ADR 子决策
- **运行时无状态**：Replit 实例不承载唯一真相数据，不将 memo/附件持久化到本地磁盘作为正式存储。
- **数据库介质**：托管 Postgres，支持 schema migration、逻辑备份与恢复验证。
- **附件介质**：私有 S3 兼容对象存储，路径按 `user_id/memo_id/<uuid>` 命名。
- **恢复目标**：
  - `RPO <= 24h`
  - `RTO <= 4h`
- **备份策略**：
  - 每日数据库逻辑备份
  - 每日对象存储清单快照
  - 每周一次非生产恢复演练并记录结果
- **容量/回收策略**：
  - v1 每条 memo 最多 1 张图片
  - 单图最大 5MB，仅允许 `jpg/png/webp`
  - 每用户软配额 200MB
  - 删除/替换 memo 图片时同步删元数据、异步删对象
  - 每日孤儿对象扫描一次

---

## 3) PRD-Style Implementation Plan

## 3.1 Architecture（v1）
- **Frontend**：中文响应式 Dashboard（登录页、主面板、memo 编辑器、城市管理、假期区块）。
- **Backend API**：
  - Auth：注册、登录、登出、会话校验
  - Memo：CRUD + 到期查询
  - Upload：图片上传、校验、访问授权、删除回收
  - Weather/Holiday：按城市和未来 90 天聚合展示
- **Data Model（核心）**：
  - `users`（id, email/username, password_hash, created_at）
  - `sessions`（id, user_id, token_hash, created_at, last_seen_at, idle_expires_at, absolute_expires_at, rotated_from_session_id）
  - `memos`（id, user_id, title, content, remind_at_utc, reminder_acknowledged_at, last_notified_at, created_at, updated_at）
  - `memo_attachments`（id, memo_id, user_id, object_key, mime, size, checksum, deleted_at）
  - `saved_cities`（id, user_id, city_code, city_name, is_default）
  - `user_preferences`（user_id, timezone, locale, holiday_region, holiday_window_days）
- **Auth / Session Semantics**：
  - Idle TTL：7 天
  - Absolute TTL：30 天
  - Token 轮换：登录成功、密码变更、显式刷新以及每 24 小时主动轮换
  - 并发会话上限：5
  - 当前端登出：仅失效当前 session
  - 密码变更：失效该用户全部 session
- **Isolation Controls**：
  - 服务层统一注入 `session.user_id`
  - 查询必须带 `user_id` 断言
  - 上传路径按 `user_id/` 命名空间分隔
  - 附件只通过受保护 API `GET /api/attachments/:id` 下发，不暴露公共直链
- **Reminder Mechanism（站内）**：
  - 服务端统一以 UTC 存储 `remind_at_utc`，用户偏好中保存时区用于展示/输入转换
  - 前端在页面可见时每 60 秒轮询一次，并在登录成功、标签页重新聚焦时立即刷新
  - “到点”定义为 `remind_at_utc <= now_utc` 且 `reminder_acknowledged_at IS NULL`
  - UI 显示显著提醒条/弹层，并在列表中持续展示未确认到期事项
  - 用户确认后写入 `reminder_acknowledged_at`
  - 若页面离线/关闭，重连或重新登录时补发全部“已到期未确认”事项
- **Provider Contracts**：
  - `weatherProvider`：只拉取当前天气；响应缓存 TTL 10 分钟；失败时显示降级文案，不阻塞 memo 区域
  - `holidayProvider`：v1 默认使用中国大陆法定节假日口径，返回未来 90 天窗口；缓存 TTL 24 小时；上游失败时优先返回最近一次成功快照并标记“数据可能非最新”

## 3.2 Phased Delivery

### Phase 0 — Project bootstrap & security baseline
- 建立项目骨架、环境变量、基础日志、错误处理、速率限制、输入校验。
- 明确托管 Postgres / 私有对象存储 / provider key 的配置与恢复流程。
- **Exit criteria**：基础健康检查通过；安全中间件已启用。

### Phase 1 — Auth + user isolation
- 完成注册/登录/登出/会话持久化；受保护路由；未登录禁止访问私密数据；session TTL/轮换/全端失效策略落地。
- **Exit criteria**：跨账号访问拦截测试 100% 通过。

### Phase 2 — Memo CRUD + image attachments
- 完成 memo 增删改查、图片上传/预览/删除、文件类型与大小限制、对象回收与配额提示。
- **Exit criteria**：同账号全流程可用；越权访问附件被拒。

### Phase 3 — Reminder + weather/cities + 90-day holidays
- 完成站内提醒、城市手动选择与收藏、天气展示、未来 90 天假期展示；实现 provider 缓存与降级策略。
- **Exit criteria**：提醒到点可见；城市偏好持久化；假期窗口正确。

### Phase 4 — Hardening + deployment on Replit
- 性能/安全回归、部署配置、初始化数据策略、运维手册。
- **Exit criteria**：公网可访问，核心验收项全部通过。

## 3.3 Stories（精炼）
1. 作为用户，我可以注册并登录，且只能看到自己的数据。
2. 作为用户，我可以创建/编辑/删除 memo，并上传图片附件。
3. 作为用户，我可为 memo 设置提醒时间，到点后在站内被明显提示。
4. 作为用户，我可以手动选择城市查看天气，并保存常用城市。
5. 作为用户，我可以查看未来 90 天假期信息。
6. 作为用户，我可以在手机和桌面使用同一账号访问同一数据。

## 3.4 Acceptance Criteria Refinements（补充）
- 登录态失效后访问受保护 API 返回 401 且前端跳转登录页。
- 任意 API 请求中伪造他人 `memo_id` 必须返回 403/404，不泄露存在性细节。
- 上传仅允许白名单图片类型（如 jpg/png/webp），并限制尺寸与总量。
- 提醒“明显提示”定义：页面可见区域内出现高对比提示组件，并需用户手动确认关闭。
- 提醒时序以 UTC 判断到期、以用户时区展示；轮询允许最多 60 秒可接受延迟。
- 假期窗口计算以服务器日期为基准，严格 `today ~ today+90d`；v1 口径为中国大陆法定节假日。
- 假期/天气上游失败时不得阻断登录和 memo 主流程，必须显示降级状态。

## 3.5 Risks & Mitigations
- **R1 数据泄露风险**：遗漏 `user_id` 过滤。→ 强制仓储层封装 + 集成越权测试。
- **R2 上传滥用风险**：恶意文件/超大文件。→ MIME+扩展名双校验、大小上限、频控。
- **R3 提醒可靠性认知偏差**：用户关闭页面后无提醒。→ UI 明确“仅站内在线提醒”。
- **R4 持久化不明确导致数据丢失**：把正式数据写在 Replit 本地磁盘。→ 数据库/对象存储外置 + 备份 + 周恢复演练。

## 3.6 Security & Privacy Notes
- 密码哈希（Argon2/bcrypt）、最小密码策略、登录限流、防爆破。
- 会话令牌仅存 HttpOnly/Secure Cookie（生产 HTTPS）。
- 会话支持 idle / absolute TTL、轮换、防 fixation/replay。
- 上传文件禁止脚本执行；附件仅经受保护 API 代理；对象 key 不可猜测。
- 上传执行 MIME+扩展名双校验、用户软配额与删除回收。
- 日志脱敏：不记录密码/原始 token/敏感 memo 正文。

## 3.7 Deployment Considerations (Replit)
- 环境变量：`DATABASE_URL`, `SESSION_SECRET`, `OBJECT_STORAGE_BUCKET`, `OBJECT_STORAGE_ENDPOINT`, `OBJECT_STORAGE_ACCESS_KEY`, `OBJECT_STORAGE_SECRET_KEY`, `WEATHER_API_KEY`（如需）, `HOLIDAY_REGION=CN`。
- 首次部署迁移：schema migration + admin-free signup。
- 公网发布前检查：
  - Cookie 安全属性
  - CORS/CSRF 策略
  - 生产日志级别与错误页不泄露堆栈
  - 对象存储 bucket 为私有且下载经受保护 API
- 数据备份策略：
  - 数据库每日逻辑备份
  - 对象存储每日清单快照
  - 每周一次恢复演练，门禁要求：4 小时内恢复到最近 24 小时内的数据点

## 3.8 Available-Agent-Types Roster（本任务推荐）
- `architect`, `executor`, `test-engineer`, `security-reviewer`, `verifier`, `writer`, `debugger`, `build-fixer`, `critic`

## 3.9 Staffing Guidance

### A) Ralph 单人持续闭环（适合中小迭代）
- Owner lane：`executor`（high）
- Embedded checks：
  - `security-reviewer`（medium，阶段门）
  - `test-engineer`（medium，补全回归）
  - `verifier`（high，发布前证据审计）
- 适用：需求稳定、变更集中、需要持续修复直到验收通过。

### B) Team 并行协作（建议 deliberate 模式采用）
- Lane 1：`architect`（high）— 收敛接口/模型/安全边界
- Lane 2：`executor`（high）— Auth + isolation + Memo/Upload 主实现
- Lane 3：`executor`（medium）— Weather/Holiday/City + Dashboard UI
- Lane 4：`test-engineer`（high）— 集成/E2E/越权回归
- Lane 5：`security-reviewer`（medium）— 上传与会话攻防检查
- Lane 6：`verifier`（high）— 汇总证据、发布门禁

## 3.10 Suggested Reasoning Levels by Lane
- 架构与安全边界：**high**
- 主业务实现：**high**
- 次要模块实现（天气/假期/城市）：**medium**
- 测试设计与证据核验：**high**
- 文档与交付说明：**medium**

## 3.11 Launch Hints (`omx team` / `$team`)
- 建议启动：
  - `omx team 6:executor "replit dashboard v1 delivery with auth isolation upload reminder weather holiday"`
  - 或 `$team 6:executor "..."`
- 启动后立即分派 lane 角色（在 team state/inbox 明确 owner 文件边界与验收件）。

## 3.12 Concrete Team Verification Path
1. **设计门**：`architect + security-reviewer` 先签字 API/数据隔离策略。
2. **实现门**：两个 `executor` 分 lane 合并前必须通过本 lane 单测。
3. **系统门**：`test-engineer` 跑集成+E2E（含越权、上传、提醒、90天假期窗口）。
4. **安全门**：`security-reviewer` 出具“高危=0、可接受中危有缓解”报告。
5. **发布门**：`verifier` 汇总测试报告、日志证据、部署检查清单后才允许 shutdown。

---

## 4) Deliberate-mode Pre-mortem（3 个失败场景）
1. **失败场景 A：公开部署后发生跨用户数据可见**
   - 触发：某查询漏加 `user_id`。
   - 前兆：越权测试缺失/偶发返回他人记录。
   - 预防：仓储层统一鉴权封装 + 必测越权用例 + 发布前渗透脚本。

2. **失败场景 B：图片上传通道被滥用导致存储/安全问题**
   - 触发：未做 MIME/大小/频率限制。
   - 前兆：异常大文件、非图片扩展、上传错误率高。
   - 预防：白名单校验 + 大小阈值 + 速率限制 + 失败审计。

3. **失败场景 C：提醒体验不符合预期引发“功能失效”认知**
   - 触发：用户离开页面后无提醒，但未被明确告知。
   - 前兆：反馈“没提醒到”。
   - 预防：设置页与提醒组件明确“仅站内在线提醒”；提供最近到期列表兜底。
