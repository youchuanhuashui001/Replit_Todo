# RALPLAN Draft: Replit Personal Dashboard

## Metadata
- Source spec: `.omx/specs/deep-interview-replit-dashboard.md`
- Context snapshot: `.omx/context/replit-dashboard-20260418T131405Z.md`
- Planning mode: consensus
- Deliberate mode: enabled
- Risk signals: auth/security, public deployment, private user content, image upload

## RALPLAN-DR Summary

### Principles
1. **Privacy before convenience**: any plan choice must protect user memo content on a publicly accessible deployment.
2. **MVP by bounded scope**: ship the required personal-dashboard experience first; defer collaboration, social login, and off-site notifications.
3. **Prefer managed persistence over host-local state**: user notes and images must survive restarts/deployments and work across devices.
4. **Derived data stays replaceable**: weather and holiday providers should sit behind thin adapters so provider changes do not spill through the app.
5. **Responsive daily-use UX**: the dashboard must be usable on phone and desktop with Chinese-first copy and obvious reminder visibility.

### Decision Drivers
1. **Secure user isolation on a public Replit app**.
2. **Reliable cross-device persistence for notes, images, and settings**.
3. **Low-ops implementation path that a single-owner MVP can realistically ship and maintain**.

### Viable Options
| Option | Summary | Pros | Cons |
| --- | --- | --- | --- |
| A | **Next.js + Supabase Auth/Postgres/Storage + provider adapters** | Strong auth primitives; row-level data isolation; durable image storage; fits full-stack web app; reduces custom backend surface | External service dependency; more env/config setup; storage/auth policies must be configured correctly |
| B | Next.js + SQLite/local file uploads on Replit | Simple local development; fewer moving parts at first; no external DB vendor | Weak durability across deploy/runtime changes; unsafe/fragile for private uploads; harder backup/recovery; poor path for multi-device reliability |
| C | React + Express API + Postgres + object storage | More backend control; clear API split; portable beyond Replit | More boilerplate; larger auth/session surface; slower MVP for one owner |

### Chosen Direction
**Option A** — Next.js on Replit with Supabase for email/password auth, Postgres persistence, and object storage.

### Why Option A wins
- It best satisfies the privacy + persistence drivers without requiring a bespoke auth/storage stack.
- It keeps the deployed app public while making private content isolation enforceable through user-scoped access rules.
- It shortens the MVP path compared with a split React/Express stack, while avoiding the durability risks of host-local SQLite/uploads.

### Alternatives invalidated
- **Option B invalidated** because persistent private images and cross-device reliability are first-order requirements, not nice-to-haves.
- **Option C invalidated for MVP** because the extra server/API layer increases implementation and security surface without clear user-facing benefit in v1.

## ADR
### Decision
Build the app as a Replit-hosted Next.js application with:
- Supabase email/password authentication
- Supabase Postgres for app data
- Supabase Storage for memo images
- A server-rendered/authenticated dashboard shell
- Adapter-style integration for weather and holiday data providers

### Drivers
- Public deployment with private user data
- Cross-device access for the same account
- Image attachment support
- Minimal operations burden for a solo MVP
- Clear path to mobile-responsive UI

### Alternatives considered
1. **Host-local SQLite + file uploads**
2. **Custom Express API + Postgres + S3-style storage**
3. **Serverless/BaaS-heavy SPA with a separate frontend**

### Why chosen
The chosen stack gives the narrowest custom security surface while still supporting custom UI, memo CRUD, attachments, and provider-backed dashboard widgets. It is the best trade-off between implementation speed, privacy, and durability.

### Consequences
- The implementation depends on managed external services and environment variables.
- Auth, database schema, storage buckets, and access policies must be planned/tested early.
- Provider abstraction should exist from day one so weather/holiday APIs can change later.

### Follow-ups
- Decide exact weather provider during implementation based on key availability/cost.
- Confirm holiday data source (default Chinese mainland holidays for v1 unless later expanded).
- Add migration path notes if a future self-hosted backend is desired.

## Product Scope
### User Problem
The user wants a private personal dashboard that is always reachable from multiple devices, combining memo capture with quick-glance situational info (time/date, weather, upcoming holidays) in one place.

### Success Definition
The MVP is successful when a user can register, log in from phone or desktop, create/edit/delete private memos with optional images and reminder time, see due reminders prominently in the app, and view current time/date, weather for a selected/saved city, and upcoming holidays for the next 90 days in a Chinese UI.

### Explicit Non-goals
- Multi-user collaboration or shared workspaces
- Social/third-party login
- Browser push/system notifications, email, SMS, or repeated reminders
- Full calendar planning/scheduling suite
- Rich collaborative media management beyond single-user memo images

## Architecture Plan
### App Surfaces
1. **Public auth surface**
   - 登录
   - 注册
   - 会话失效后的重新认证
2. **Authenticated dashboard**
   - 顶部概览：当前时间/日期
   - 备忘录主区：列表/卡片、创建、编辑、删除、图片附件
   - 提醒区：已到点未处理事项高亮展示
   - 天气卡片：当前城市天气 + 常用城市快捷切换
   - 假期卡片：未来 90 天假期列表
   - 设置区：常用城市管理、基础个人设置、退出登录

### Domain Model (initial)
- `profiles`
  - `user_id`
  - `display_name` (optional)
  - `locale` (default `zh-CN`)
  - `timezone` (default from browser/user setting)
- `memos`
  - `id`
  - `user_id`
  - `title`
  - `content`
  - `image_path` (optional)
  - `remind_at` (optional)
  - `reminder_acknowledged_at` (optional)
  - `created_at`
  - `updated_at`
- `saved_cities`
  - `id`
  - `user_id`
  - `city_name`
  - `provider_location_key`
  - `is_default`
  - `created_at`
- `user_preferences`
  - `user_id`
  - `holiday_region` (default `CN` for v1)
  - `holiday_window_days` (default `90`)

### Security Model
- All user-created rows are scoped by `user_id`.
- Storage paths for images are user-namespaced.
- Database/storage access policies prevent cross-user reads.
- Server-side auth checks gate all memo/image mutations.
- File uploads are validated for size/type before persistence.

### Integration Boundaries
- `weatherProvider` adapter returns normalized current-weather data by city key.
- `holidayProvider` adapter returns normalized holiday items for a region/window.
- Reminder evaluation is internal app logic: due memos are computed in authenticated queries/UI state; no background worker required in v1.

## Delivery Plan

### Phase 0 — Scaffold & Risk Controls
**Goal:** establish the production shape before feature work.
- Create app shell, TypeScript standards, env handling, and deployment config for Replit.
- Set up Supabase project, auth mode, DB schema baseline, storage bucket strategy.
- Define route protection approach and server/client responsibility boundaries.
- Add baseline observability hooks (structured server logs, client error boundary/reporting stub).

**Exit criteria**
- App boots locally/in Replit preview.
- Env variables documented.
- Auth/storage/database responsibilities are explicit.
- Threat checklist exists for auth + uploads.

### Phase 1 — Auth & Private Data Foundation
**Goal:** make privacy guarantees real.
- Implement register/login/logout with email/password.
- Guard authenticated routes and redirect public users.
- Create memo, city, preference schemas and row-level policies.
- Add basic profile/timezone handling.

**Exit criteria**
- Users can register and log in.
- Unauthenticated visitors cannot access dashboard data.
- User A cannot read/write User B memo records.

### Phase 2 — Memo CRUD, Images, and In-App Reminders
**Goal:** deliver the product’s primary utility.
- Build memo list/detail/create/edit/delete flows.
- Support image upload, preview, replace, and delete.
- Support optional reminder datetime on memos.
- Highlight due/unacknowledged memos in dashboard and memo list.
- Allow reminder acknowledgment or completion dismissal.

**Exit criteria**
- Memo CRUD works end-to-end.
- Images persist and remain user-private.
- Due reminders are clearly visible in-app.

### Phase 3 — Weather, Holidays, and Dashboard Refinement
**Goal:** complete the dashboard experience.
- Implement current time/date display with Chinese formatting.
- Add weather module with manual city selection.
- Add saved-city management and default city behavior.
- Add holiday module for next 90 days with normalized display.
- Optimize layout for mobile and desktop.

**Exit criteria**
- Current city weather displays reliably.
- Saved city switching works.
- Holiday list renders for the next 90 days.
- Mobile/desktop layouts are usable without hidden blockers.

### Phase 4 — QA, Hardening, and Publish Readiness
**Goal:** reach a safe publishable MVP.
- Validate auth/session edge cases.
- Validate upload size/type, broken image handling, empty provider responses, timezone behavior.
- Add polish for Chinese copy, loading/empty/error states.
- Produce deployment checklist and rollback notes.

**Exit criteria**
- Acceptance criteria pass.
- Critical-path tests are green.
- Publish checklist is complete.

## Story Map / Work Breakdown
1. **As a visitor**, I can register and log in with email/password.
2. **As an authenticated user**, I can only see my own dashboard and private memo data.
3. **As an authenticated user**, I can create, edit, delete, and review memos.
4. **As an authenticated user**, I can attach an image to a memo.
5. **As an authenticated user**, I can assign a reminder time and later see due reminders in the app.
6. **As an authenticated user**, I can choose a city manually and save common cities.
7. **As an authenticated user**, I can view current weather for the selected city.
8. **As an authenticated user**, I can view the next 90 days of holidays.
9. **As an authenticated user**, I can use the app on phone and desktop with Chinese UI.

## Acceptance Criteria Refinements
- Registration requires unique email and password meeting a defined minimum policy.
- Session-protected routes never flash private content before auth state resolves.
- Memo attachments reject unsupported file types and oversized payloads.
- Reminder UI distinguishes overdue vs upcoming-soon items.
- Weather/holiday cards show useful fallback states when providers fail.
- Saved city management prevents accidental duplicate defaults.
- Time/date and reminder comparisons use the user’s effective timezone.

## Risks & Mitigations
| Risk | Impact | Mitigation |
| --- | --- | --- |
| Misconfigured auth/storage policies expose private memo or image data | Severe privacy failure | Build policy tests early; keep server-side guards; add explicit cross-user negative tests |
| Replit deployment/env misconfiguration breaks auth callbacks or provider access | App unusable | Phase 0 deployment checklist; validate env loading in preview and deploy targets |
| Image uploads become an abuse/vector issue (size/type) | Storage cost, failures, security concerns | Enforce type/size validation, user namespacing, and upload error handling |
| Weather or holiday provider changes/fails | Partial dashboard failure | Use thin adapters and graceful degraded UI |
| Timezone mismatch causes wrong reminder timing | Core trust issue | Persist timezone preference and test cross-timezone scenarios |

## Security & Privacy Notes
- Treat authentication, storage policy, and memo/image access control as release blockers.
- Avoid exposing storage bucket/object URLs without authorization context unless signed and short-lived.
- Keep private API routes server-validated even if the client already filters by user.
- Sanitize/escape rendered memo content and uploaded filename metadata.
- Prefer httpOnly secure session handling as provided by the auth stack.

## Deployment Considerations
- Replit deployment needs environment variables for auth/storage/provider keys.
- Publish only after auth redirect URLs, origin settings, and storage policies match the deployment domain.
- Separate development and production service configs where possible.
- Provide a seed-free startup path: no user should see demo private data.

## Available Agent Types Roster
- `planner` — plan maintenance, sequencing, and scope control
- `architect` — auth/storage boundary review, provider abstraction review
- `critic` — plan quality gate and tradeoff consistency
- `executor` — implementation lanes
- `test-engineer` — test design and coverage lane
- `security-reviewer` — auth, storage, upload, and privacy review
- `designer` — dashboard layout and responsive UX polish
- `verifier` — final claim validation and acceptance evidence
- `writer` — deployment notes and user-facing documentation

## Staffing Guidance
### If executed via `$ralph`
- **Primary lane:** `executor` (high reasoning) owns sequential delivery phase by phase.
- **Embedded checkpoints:**
  - `architect` (high) after auth/storage design and before publish hardening
  - `security-reviewer` (medium) before merging auth/upload work
  - `test-engineer` (medium) before final verification sweep
  - `verifier` (high) at completion

### If executed via `$team`
Recommended lanes:
1. **Lane A — App shell + auth + policies** (`executor`, high)
2. **Lane B — Memo CRUD + image attachments + reminder UX** (`executor`, high)
3. **Lane C — Weather + holidays + saved cities + formatting** (`executor`, medium/high)
4. **Lane D — QA/security/docs** (`test-engineer` + `security-reviewer` + `writer`, medium)

Coordination rule: Lane A owns shared auth/session primitives; other lanes consume, not rewrite, those boundaries.

## Suggested Reasoning Levels by Lane
- Auth/policy lane: **high**
- Memo/upload/reminder lane: **high**
- Weather/holiday lane: **medium**
- Responsive UI polish lane: **medium**
- QA/security verification lane: **high**

## Launch Hints
- Sequential path: `$ralph .omx/plans/prd-replit-dashboard.md`
- Parallel path: `$team .omx/plans/prd-replit-dashboard.md`
- Team-oriented shell hint: `omx team .omx/plans/prd-replit-dashboard.md`

## Team Verification Path
1. Lane-level unit/integration checks pass before merge.
2. Shared auth/data-isolation regression suite passes after integrating all lanes.
3. End-to-end publish-candidate run covers signup/login, memo CRUD, image attach, reminder visibility, city save/switch, weather display, holiday list, and logout.
4. Security review confirms cross-user access is denied for memo rows and images.
5. Final verifier checks acceptance criteria against deployed/preview behavior and documented env/deploy steps.

## Deliberate-Mode Pre-mortem
1. **Scenario: “Public deploy leaks private images.”**
   - Cause: storage bucket/object policy is too broad or URLs are long-lived/public.
   - Early signal: unauthenticated requests can fetch uploaded assets.
   - Preventive action: default private bucket, signed access, and negative access tests.
2. **Scenario: “Reminder trust collapses because times are wrong.”**
   - Cause: browser locale/timezone mismatch or UTC/local conversion bug.
   - Early signal: reminders show overdue/early on one device but not another.
   - Preventive action: explicit timezone handling, normalized storage, cross-device/timezone tests.
3. **Scenario: “MVP stalls on integration sprawl.”**
   - Cause: provider setup, auth wiring, and upload handling are all attempted before a thin vertical slice works.
   - Early signal: many incomplete modules, no end-to-end usable flow.
   - Preventive action: deliver in vertical slices—auth/privacy first, then memo value, then derived dashboard widgets.

## Expanded Test Plan
### Unit
- Auth form validation, password rules, and route-guard helpers
- Memo form validation, reminder datetime parsing, due-state classification
- Upload validation (file type/size), city dedupe/default selection logic
- Weather/holiday adapter normalization and fallback mapping

### Integration
- Authenticated server actions/routes for memo CRUD
- Storage upload/delete lifecycle tied to memo updates/deletes
- Cross-user access denial for memo rows and images
- Saved city persistence and default city switching
- Provider failure/timeout handling in dashboard loaders

### E2E
- Register -> login -> create memo -> upload image -> set reminder -> see due reminder
- Logout/login on another device viewport -> see same user data
- Attempt unauthenticated/private-route access -> redirect with no content leak
- Save multiple cities -> switch city -> weather updates
- Holiday list renders next 90 days in Chinese UI

### Observability
- Structured server logs for auth failures, provider errors, and upload failures
- Dashboard error boundary or equivalent client fallback instrumentation
- Deployment checklist includes env verification and smoke-test steps
- Manual privacy audit checklist for pre-publish validation
