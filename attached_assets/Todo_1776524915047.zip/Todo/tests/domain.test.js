import test from 'node:test';
import assert from 'node:assert/strict';
import { filterUpcomingHolidays, isReminderDue, validatePassword } from '../src/domain.js';

test('validatePassword enforces length and alphanumeric mix', () => {
  assert.equal(validatePassword('short'), '密码至少需要 8 位');
  assert.equal(validatePassword('abcdefgh'), '密码需要同时包含字母和数字');
  assert.equal(validatePassword('abc12345'), null);
});

test('isReminderDue respects acknowledge flag and due time', () => {
  const now = Date.parse('2026-04-18T10:00:00Z');
  assert.equal(isReminderDue({ remindAt: '2026-04-18T09:00:00Z', reminderAcknowledgedAt: null }, now), true);
  assert.equal(isReminderDue({ remindAt: '2026-04-18T11:00:00Z', reminderAcknowledgedAt: null }, now), false);
  assert.equal(isReminderDue({ remindAt: '2026-04-18T09:00:00Z', reminderAcknowledgedAt: '2026-04-18T09:05:00Z' }, now), false);
});

test('filterUpcomingHolidays keeps only next 90-day holidays', () => {
  const holidays = [
    { date: '2026-04-20', localName: 'A' },
    { date: '2026-06-15', localName: 'B' },
    { date: '2026-08-30', localName: 'C' }
  ];
  const result = filterUpcomingHolidays(holidays, new Date('2026-04-18T00:00:00Z'), 90);
  assert.deepEqual(result.map((item) => item.localName), ['A', 'B']);
});
