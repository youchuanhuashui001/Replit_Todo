import test from 'node:test';
import assert from 'node:assert/strict';
import { createSessionToken, hashPassword, verifyPassword } from '../src/auth.js';

test('hashPassword and verifyPassword roundtrip', () => {
  const hash = hashPassword('abc12345');
  assert.equal(verifyPassword('abc12345', hash), true);
  assert.equal(verifyPassword('wrong-pass', hash), false);
});

test('createSessionToken returns non-empty random string', () => {
  const tokenA = createSessionToken();
  const tokenB = createSessionToken();
  assert.ok(tokenA.length > 20);
  assert.notEqual(tokenA, tokenB);
});
