# Replit 个人仪表盘（MVP）

一个可在 Replit 发布的中文个人仪表盘，包含：
- 账号注册 / 登录
- 私密备忘录
- 图片附件
- 站内提醒
- 当前时间 / 日期
- 手动选择城市天气
- 未来 90 天假期

## 本地运行

```bash
npm start
```

默认端口：`3000`

## 在 Replit 中发布

### 推荐部署类型
这是一个带后端的 Web 应用，应该使用 **Autoscale Deployment** 或 **Reserved VM Deployment**，**不要**用 Static Deployment。

Replit 官方文档说明：
- `.replit` 可配置 `run` 和 `[deployment].run` 启动命令。  
  来源：Replit App Configuration  
  https://docs.replit.com/core-concepts/workspace/app-setup/configuration
- 发布后的应用不应依赖写入到部署文件系统的数据；官方建议使用存储或数据库。  
  来源：Replit Publishing Overview  
  https://docs.replit.com/category/replit-deployments

### 已提供的 Replit 配置
项目已经包含：
- `.replit`
  - `entrypoint = "server.js"`
  - `run = "npm start"`
  - `[deployment].run = "npm start"`
  - `[[ports]] localPort = 3000`

### 发布步骤
1. 把当前项目导入到 Replit。
2. 确认 Replit 识别到 `.replit` 配置。
3. 点击顶部 **Run**，确认本地预览能启动。
4. 点击 **Publish**。
5. 选择：
   - **Autoscale Deployment**：适合普通 Web 应用
   - 或 **Reserved VM Deployment**：如果你想保持更稳定的常驻运行
6. 部署启动命令保持为：

```bash
npm start
```

7. 发布成功后，用生成的 `https://<your-app>.replit.app` 地址访问。

## 当前版本的重要限制

### 1. 当前数据存储仍是本地 JSON 文件
当前版本把数据写到：
- `.data/db.json`

这适合本地开发和功能演示，**不适合生产部署**。

原因：Replit 官方明确建议**不要依赖发布实例文件系统中的写入数据**。也就是说，发布后用户数据可能因为重新部署、实例切换、恢复等原因丢失或不一致。

### 2. 如果要正式上线，建议下一步升级
建议把下面两类数据迁移出去：
- 用户 / session / memo / 城市：迁移到数据库
- 图片附件：迁移到对象存储

推荐升级方向：
- Replit Database / Replit Storage
- 或托管 Postgres + 对象存储

## 适合当前版本的用途
- 原型演示
- 功能验证
- UI 预览
- 开发阶段内部试用

## 不建议直接用于生产的部分
- 真实用户长期数据
- 大量图片上传
- 重要提醒依赖
- 多人长期在线使用

## 下一步推荐
如果你准备继续，我建议下一步优先做：
1. **把本地 JSON 存储改成真实数据库**
2. 把图片从 `data URL` 改成对象存储
3. 增加生产环境初始化与迁移脚本
